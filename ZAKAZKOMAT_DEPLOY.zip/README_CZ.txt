ZAKÁZKOMAT – aplikace pro Cloudflare Pages + D1

OBSAH
- veřejný web a formulář poptávky
- registrace zákazníka a řemeslníka / firmy
- přihlášení, odhlášení, zabezpečená session cookie (HttpOnly, Secure, SameSite)
- zákaznický přehled vlastních poptávek
- řemeslnický inbox zakázek a tlačítka Mám zájem / Odmítnout
- automatické párování poptávek podle oboru a textově zadaných oblastí
- in-app oznámení
- administrační přehled a změna stavů
- CZ veřejný web; účetní rozhraní zatím v češtině

NASAZENÍ
1. Nasazujte jako Cloudflare Pages projekt s Functions, přes Git integraci nebo Wrangler. Nepoužívejte Direct Upload pro Functions.
2. Nastavte D1 binding: proměnná DB, databáze zakazkomat, ID a0218e79-0e43-4f59-93bb-f8f7561826d8.
3. Spusťte migrace v pořadí: migrations/0001_create_leads.sql a poté migrations/0002_accounts_and_distribution.sql. Druhá migrace obsahuje ALTER TABLE leads ADD COLUMN, spusťte ji pouze jednou.
4. Zaregistrujte si běžný účet. Poté v D1 konzoli povyšte přesně tento účet na admin příkazem: UPDATE users SET role='admin' WHERE email='VAS_EMAIL';. Nedělejte administrátora pouze podle neověřeného e-mailu, protože aplikace zatím nemá ověřování e-mailové adresy.
5. Znovu nasaďte projekt a ověřte /api/health, registraci, přihlášení, uložení poptávky, automatické párování a administraci.

DŮLEŽITÉ OMEZENÍ / PŘED OSTRÝM PROVOZEM
- Poptávky se ukládají do D1 a nabídky se zobrazují v interním inboxu řemeslníka. Pro e-mailové upozornění nastavte Pages secrets RESEND_API_KEY a MAIL_FROM (ověřená adresa/doména v Resend). Bez nich fungují pouze interní oznámení. SMS není zapojeno.
- Párování oblasti je jednoduché porovnání textu města/oblasti, nikoli geokódování. Řemeslník musí při registraci uvést oblasti oddělené čárkou.
- Veřejný formulář přijímá i nepřihlášené zákazníky; tyto poptávky vidí administrátor a vhodní řemeslníci, ale nejsou přiřazeny k zákaznickému účtu.
- Před komerčním spuštěním doplňte úplnou identifikaci provozovatele, právní texty, retenční pravidla, kontaktní a reklamační proces. Ověřte soulad GDPR a bezpečnostní nastavení.
- Účetní UI je v této verzi pouze česky. Přepínač CZ/EN/DE a překlady nejsou implementovány.
- Není zde ověřování e-mailu, reset hesla, MFA, fakturace ani online platby.
- Hesla se ukládají jako PBKDF2-HMAC-SHA256 hash se solí (210 000 iterací); session token je uložen pouze jako SHA-256 hash.

Toto je funkční MVP základ, ne hotová plně auditovaná komerční platforma. Před zveřejněním proveďte testy na stagingu a bezpečnostní revizi.
