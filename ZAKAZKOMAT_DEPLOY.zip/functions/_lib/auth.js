const json=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store","x-content-type-options":"nosniff"}});
const enc=new TextEncoder(); export {json};
export async function hashPassword(password,salt){const key=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveBits"]);const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt:enc.encode(salt),iterations:210000,hash:"SHA-256"},key,256);return [...new Uint8Array(bits)].map(x=>x.toString(16).padStart(2,"0")).join("");}
export async function sha(text){const b=await crypto.subtle.digest("SHA-256",enc.encode(text));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");}
export function cookieToken(req){const m=(req.headers.get("Cookie")||"").match(/(?:^|;\s*)zk_session=([A-Za-z0-9_-]+)/);return m?.[1]||"";}
export async function currentUser(req,env){if(!env.DB)return null;const token=cookieToken(req);if(!token)return null;const row=await env.DB.prepare(`SELECT u.id,u.name,u.email,u.phone,u.role,u.company,u.categories_json,u.service_areas FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at > datetime('now') AND u.active=1`).bind(await sha(token)).first();if(!row)return null;try{row.categories=JSON.parse(row.categories_json||"[]")}catch{row.categories=[]}delete row.categories_json;return row;}
export const setCookie=(token,maxAge=1209600)=>`zk_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
export const clearCookie=()=>"zk_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0";
export const validEmail=s=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s);
