export async function onRequestGet({ env }) {
  if (!env.DB) return new Response(JSON.stringify({ ok: false, database: "unavailable" }), {
    status: 503, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
  });
  try {
    await env.DB.prepare("SELECT 1 AS ok").first();
    return new Response(JSON.stringify({ ok: true, database: "connected" }), {
      headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
    });
  } catch {
    return new Response(JSON.stringify({ ok: false, database: "query_failed" }), {
      status: 503, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
    });
  }
}
